package com.example.a3_2assignment_king;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    // Database name and version
    public static final String DB_NAME = "AppDatabase.db";
    public static final int DB_VERSION = 1;

    // Table name and columns
    public static final String USER_TABLE = "Users";
    public static final String COL_ID = "id";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password";

    // Events table
    public static final String EVENT_TABLE = "Events";
    public static final String COL_EVENT_ID = "event_id";
    public static final String COL_EVENT_NAME = "event_name";
    public static final String COL_EVENT_DATE = "event_date";
    public static final String COL_EVENT_TIME = "event_time";
    public static final String COL_EVENT_CATEGORY = "event_category";

    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + USER_TABLE + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USERNAME + " TEXT, " +
                COL_PASSWORD + " TEXT)");

        db.execSQL("CREATE TABLE " + EVENT_TABLE + " (" +
                COL_EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_EVENT_NAME + " TEXT, " +
                COL_EVENT_DATE + " TEXT, " +
                COL_EVENT_TIME + " TEXT, " +
                COL_EVENT_CATEGORY + " TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + USER_TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + EVENT_TABLE);
        onCreate(db);
    }

    // Register new user
    public boolean registerUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);
        long result = db.insert(USER_TABLE, null, values);
        return result != -1; // returns true if insert successful
    }

    // Check if user exists
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + USER_TABLE +
                        " WHERE " + COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                new String[]{username, password});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    // Event CRUD methods
    public boolean addEvent(String name, String date, String time, String category) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_EVENT_NAME, name);
        values.put(COL_EVENT_DATE, date);
        values.put(COL_EVENT_TIME, time);
        values.put(COL_EVENT_CATEGORY, category);
        long result = db.insert(EVENT_TABLE, null, values);
        return result != -1;
    }
    public Cursor getAllEvents() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + EVENT_TABLE, null);
    }
    public boolean updateEvent(int id, String name, String date, String time, String category) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_EVENT_NAME, name);
        values.put(COL_EVENT_DATE, date);
        values.put(COL_EVENT_TIME, time);
        values.put(COL_EVENT_CATEGORY, category);
        int rows = db.update(EVENT_TABLE, values, COL_EVENT_ID + "=?", new String[]{String.valueOf(id)});
        return rows > 0;
    }
    public boolean deleteEvent(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(EVENT_TABLE, COL_EVENT_ID + "=?", new String[]{String.valueOf(id)});
        return rows > 0;
    }
}

