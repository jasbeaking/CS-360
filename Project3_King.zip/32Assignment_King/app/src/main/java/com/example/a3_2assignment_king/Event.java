package com.example.a3_2assignment_king;

public class Event {
    private int id;
    private String name;
    private String date;
    private String time;
    private String category;

    public Event(int id, String name, String date, String time, String category) {
        this.id = id;
        this.name = name;
        this.date = date;
        this.time = time;
        this.category = category;
    }

    // Getters
    public int getId() { return id; }
    public String getName() { return name; }
    public String getDate() { return date; }
    public String getTime() { return time; }
    public String getCategory() { return category; }
}

