package com.example.a3_2assignment_king;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import android.database.Cursor;

public class EventListActivity extends AppCompatActivity {

    private DBHelper dbHelper;
    private RecyclerView recyclerView;
    private EventAdapter adapter;
    private List<Event> eventList;
    private Button addEventButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_list);

        dbHelper = new DBHelper(this);
        recyclerView = findViewById(R.id.recyclerViewEvents);
        addEventButton = findViewById(R.id.addEventButton);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        eventList = new ArrayList<>();
        adapter = new EventAdapter(eventList, new EventAdapter.OnEventClickListener() {
            @Override
            public void onEventClick(Event event) {
                showEditEventDialog(event);
            }
            @Override
            public void onEventLongClick(Event event) {
                showDeleteEventDialog(event);
            }
        });
        recyclerView.setAdapter(adapter);

        loadEvents();

        addEventButton.setOnClickListener(v -> showAddEventDialog());
    }

    private void loadEvents() {
        eventList.clear();
        Cursor cursor = dbHelper.getAllEvents();
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(DBHelper.COL_EVENT_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.COL_EVENT_NAME));
                String date = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.COL_EVENT_DATE));
                String time = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.COL_EVENT_TIME));
                String category = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.COL_EVENT_CATEGORY));
                eventList.add(new Event(id, name, date, time, category));
            } while (cursor.moveToNext());
        }
        cursor.close();
        adapter.notifyDataSetChanged();
    }

    private void showAddEventDialog() {
        LayoutInflater inflater = LayoutInflater.from(this);
        final android.view.View dialogView = inflater.inflate(R.layout.dialog_add_event, null);
        final EditText nameInput = dialogView.findViewById(R.id.inputEventName);
        final EditText dateInput = dialogView.findViewById(R.id.inputEventDate);
        final EditText timeInput = dialogView.findViewById(R.id.inputEventTime);
        final EditText categoryInput = dialogView.findViewById(R.id.inputEventCategory);

        new AlertDialog.Builder(this)
                .setTitle("Add Event")
                .setView(dialogView)
                .setPositiveButton("Add", (dialog, which) -> {
                    String name = nameInput.getText().toString();
                    String date = dateInput.getText().toString();
                    String time = timeInput.getText().toString();
                    String category = categoryInput.getText().toString();
                    if (dbHelper.addEvent(name, date, time, category)) {
                        Toast.makeText(this, "Event added", Toast.LENGTH_SHORT).show();
                        loadEvents();
                    } else {
                        Toast.makeText(this, "Failed to add event", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showEditEventDialog(Event event) {
        LayoutInflater inflater = LayoutInflater.from(this);
        final android.view.View dialogView = inflater.inflate(R.layout.dialog_add_event, null);
        final EditText nameInput = dialogView.findViewById(R.id.inputEventName);
        final EditText dateInput = dialogView.findViewById(R.id.inputEventDate);
        final EditText timeInput = dialogView.findViewById(R.id.inputEventTime);
        final EditText categoryInput = dialogView.findViewById(R.id.inputEventCategory);

        nameInput.setText(event.getName());
        dateInput.setText(event.getDate());
        timeInput.setText(event.getTime());
        categoryInput.setText(event.getCategory());

        new AlertDialog.Builder(this)
                .setTitle("Edit Event")
                .setView(dialogView)
                .setPositiveButton("Update", (dialog, which) -> {
                    String name = nameInput.getText().toString();
                    String date = dateInput.getText().toString();
                    String time = timeInput.getText().toString();
                    String category = categoryInput.getText().toString();
                    if (dbHelper.updateEvent(event.getId(), name, date, time, category)) {
                        Toast.makeText(this, "Event updated", Toast.LENGTH_SHORT).show();
                        loadEvents();
                    } else {
                        Toast.makeText(this, "Failed to update event", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showDeleteEventDialog(Event event) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Event")
                .setMessage("Are you sure you want to delete this event?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    if (dbHelper.deleteEvent(event.getId())) {
                        Toast.makeText(this, "Event deleted", Toast.LENGTH_SHORT).show();
                        loadEvents();
                    } else {
                        Toast.makeText(this, "Failed to delete event", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}

