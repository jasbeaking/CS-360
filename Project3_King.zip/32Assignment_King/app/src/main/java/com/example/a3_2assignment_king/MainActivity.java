package com.example.a3_2assignment_king;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.text.Editable;
import android.text.TextWatcher;

import androidx.appcompat.app.AppCompatActivity;

/**
 * MainActivity demonstrates basic Android UI interaction:
 * - Displays a greeting message when a button is clicked.
 * - Validates user input before updating the UI.
 * - Dynamically enables/disables the button based on text input.
 *
 * This fulfills the Module Five assignment requirements:
 * 1. Create a function that displays a greeting.
 * 2. Validate elements and inputs.
 * 3. Dynamically enable/disable button settings.
 */

public class MainActivity extends AppCompatActivity {

    // Declare UI elements
    private EditText nameText; // Input field for user's name
    private Button buttonSayHello; // Button to trigger greeting
    private TextView textGreeting; // TextView to display greeting message

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Link Java variables to XML UI components using their IDs

        nameText = findViewById(R.id.nameText);
        buttonSayHello = findViewById(R.id.buttonSayHello);
        textGreeting = findViewById(R.id.textGreeting);

        // Initially disable the button to prevent empty submissions
        buttonSayHello.setEnabled(false);

        /**
        * Add a TextWatcher to monitor changes in the EditText field.
        * Logic:
        * - If the user enters text, enable the button.
        * - If the field is empty, disable the button.
        * This ensures dynamic UI behavior based on user input.
        */

        nameText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            // Not used in this implementation

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Enable button only when input is not empty
                buttonSayHello.setEnabled(!s.toString().trim().isEmpty());
            }

            @Override
            public void afterTextChanged(Editable s) {}
            // Not used in this implementation
        });
    }

    /**
     * SayHello() is triggered when the button is clicked.
     * Requirements:
     * - Accepts a View parameter (required for onClick binding).
     * - Validates input: If nameText is empty, do nothing.
     * - Displays "Hello [name]" in the TextView when input is valid.
     */

    public void SayHello(View view) {
        String name = nameText.getText().toString().trim();
        // Validate input: Only proceed if name is not empty
        if (!name.isEmpty()) {
            textGreeting.setText("Hello " + name);
        } else {
            return;
            // If input is empty, return without updating UI
        }
    }
}
